var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require("../native"), HttpHandler = _a.HttpHandler, Html = _a.Html, Value = _a.Value, ChapterInfo = _a.ChapterInfo, LightInfo = _a.LightInfo, DetailInfo = _a.DetailInfo, ParserDetail = _a.ParserDetail, SearchDetail = _a.SearchDetail, Parser = _a.Parser, ChapterDetail = _a.ChapterDetail;
var GogoAnime = /** @class */ (function (_super) {
    __extends(GogoAnime, _super);
    function GogoAnime() {
        var _this = _super.call(this, "https://gogoanime.by", "GoGoAnime.by", "/img/favicon.ico", "Anime") || this;
        _this.settings.searchEnabled = true;
        _this.settings.genreMultiSelection = false;
        _this.infoGeneratorName = "MyAnimeList";
        _this.settings.searchCombination = ["Genre", "Status", "Group"];
        return _this;
    }
    GogoAnime.prototype.load = function () {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        this.settings.Genre(html
                            .$("input[name*='genre']")
                            .map(function (x) {
                            return Value.n()
                                .Text(x.attr("value"))
                                .Value(x.attr("value"));
                        }).filter(function (x) { return x.text.length > 0; }));
                        this.settings.Status(html
                            .$("input[name*='status']")
                            .map(function (x) {
                            return Value.n()
                                .Text(x.attr("value"))
                                .Value(x.attr("value"));
                        }).filter(function (x) { return x.text.length > 0; }));
                        this.settings.Group(html
                            .$("input[name*='type']")
                            .map(function (x) {
                            return Value.n()
                                .Text(x.attr("value"))
                                .Value(x.attr("value"));
                        }).filter(function (x) { return x.text.length > 0; }));
                        return [2 /*return*/, this.settings];
                }
            });
        });
    };
    GogoAnime.prototype.search = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var url, q, html, data;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.url.join("/?s=".concat(options.text.replace(/ /gim, "+")));
                        //series/?genre%5B%5D=action&status=&type=Movie&order=
                        if (options.text.startsWith("#"))
                            url = this.url.join("/tag", options.text.substring(1).toUpperCase());
                        if (options.genre.has() || options.group.has() || options.status.has()) {
                            url = this.url.join("/series/?");
                        }
                        q = {};
                        if (options.genre.has())
                            options.genre.map(function (x, index) { return q["$".concat(index, "genre%5B%5D")] = x.value; });
                        if (options.status.has())
                            q.status = options.status.lastOrDefault("value");
                        if (options.group.has())
                            q.type = options.group.lastOrDefault("value");
                        url = url.query(__assign({ page: (1).sureValue(options.page) }, q));
                        return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        data = html
                            .$(".listupd a")
                            .map(function (x) {
                            return x.map(function (f) {
                                if (f.find("img").attr("src|data-src").has())
                                    return LightInfo.n()
                                        .Name(f.find("h2").text)
                                        .Url(f.url("href"))
                                        .Image(f.find("img").url("src|data-src"))
                                        .Info(f.find(".typez").text)
                                        .LangType(f.find(".sb").text)
                                        .ParserName(_this.name);
                            });
                        })
                            .flatMap(function (x) { return x; });
                        return [2 /*return*/, data];
                }
            });
        });
    };
    GogoAnime.prototype.group = function (value, page) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.search(SearchDetail.n().Group([value]).Page(page))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    GogoAnime.prototype.getByAuthor = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, []];
            });
        });
    };
    GogoAnime.prototype.chapter = function (html) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, {
                        css: "\n        body>*:not(.mvelement):not(video), .naveps{\n            display:none !important;\n            visibility:hidden !important;\n        }\n        \n        ",
                        script: "\n          const loadData = async()=>{\n                  while(document.querySelector(\".mvelement\") == null)\n                    await window.sleep(100);\n                const panel = document.querySelector(\".mvelement\");\n                document.body.appendChild(panel); \n            }\n            loadData();\n        ",
                        clickExceptions: [".servers", ".mvelement"]
                    }];
            });
        });
    };
    GogoAnime.prototype.detail = function (url) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var html, body, item;
            var _this = this;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_b.sent()).html;
                        body = html.$("body");
                        item = DetailInfo.n();
                        item
                            .Name(body.find(".entry-title").text)
                            .Url(url)
                            .Image(body.find(".thumb img").url("src|data-src"))
                            .Author(body.find('.author i').text)
                            .Genre(body.find('.genxed a').map(function (x) { return x.text; }))
                            .Status(body.find('.spe b:contains("Status")').parent.remove("b").text)
                            .LastUpdated((_a = body.find("time[itemprop='dateModified']").text) === null || _a === void 0 ? void 0 : _a.trim())
                            .ParserName(this.name)
                            .Chapters(body.find(".episodes-container a").map(function (a) { return ChapterInfo.n()
                            .Name(a.text)
                            .Url(a.url("href"))
                            .ParserName(_this.name); }).reverse());
                        item.novelUpdateRecommendations =
                            item.novelUpdateRecommendations = body
                                .find('.listupd a')
                                .map(function (f) { return LightInfo.n()
                                .Name(f.find("h2").text)
                                .Url(f.url("href"))
                                .Image(f.find("img").url("src|data-src"))
                                .Info(f.find(".typez").text)
                                .LangType(f.find(".sb").text)
                                .ParserName(_this.name); });
                        item.commentScript.Url(url + "#tab-comment-title").Script("\n          let scLoad = async function () {\n            let st =document.createElement(\"style\")\n             st.appendChild(document.createTextNode(\"body>*:not(.cmd_comment) { display:none !important;visibility: hidden;opacity:0;}\"))\n            document.head.appendChild(st);\n            while(!document.querySelector(\".commentx\"))\n             await window.sleep(100);\n             let panel = document.querySelector(\".commentx\").parentElement;\n             panel.classList.add(\"cmd_comment\")\n             document.body.appendChild(panel);\n          }\n          scLoad();\n          ");
                        return [2 /*return*/, item];
                }
            });
        });
    };
    return GogoAnime;
}(Parser));
