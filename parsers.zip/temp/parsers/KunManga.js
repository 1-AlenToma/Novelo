var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require("../native"), HttpHandler = _a.HttpHandler, Html = _a.Html, Value = _a.Value, ChapterInfo = _a.ChapterInfo, LightInfo = _a.LightInfo, DetailInfo = _a.DetailInfo, ParserDetail = _a.ParserDetail, SearchDetail = _a.SearchDetail, Parser = _a.Parser;
var KunManga = /** @class */ (function (_super) {
    __extends(KunManga, _super);
    function KunManga() {
        var _this = _super.call(this, "https://kunmanga.com", "KunManga", "/favicon.ico", "Manga") || this;
        _this.infoGeneratorName = "AnimePlanet";
        _this.settings.searchEnabled = true;
        _this.settings.genreMultiSelection = true;
        _this.settings.searchCombination = ["Genre", "Status", "Group"];
        _this.minVersion = 139;
        _this.protected = true;
        return _this;
    }
    KunManga.prototype.load = function () {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(this.url.join("?s=&post_type=wp-manga"), this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        this.settings.Genre(html.$("input[name='genre[]']").map(function (x) {
                            return Value.n()
                                .Text(x.attr("value").displayName())
                                .Value(x.attr("value"));
                        }));
                        this.settings.Status([
                            Value.n()
                                .Text("Completed")
                                .Value("end"),
                            Value.n()
                                .Text("OnGoing")
                                .Value("on-going")
                        ]);
                        this.settings.Group([
                            Value.n()
                                .Text("Latest")
                                .Value(this.url),
                            Value.n()
                                .Text("New")
                                .Value("new-manga"),
                            Value.n()
                                .Text("Most Views")
                                .Value("views"),
                            Value.n()
                                .Text("Trending")
                                .Value("trending"),
                            Value.n()
                                .Text("Rating")
                                .Value("rating"),
                        ]);
                        // console.warn([this.settings].niceJson());
                        return [2 /*return*/, this.settings];
                }
            });
        });
    };
    KunManga.prototype.parse = function (html) {
        var _this = this;
        var items = html.$(".page-content-listing > .row, .page-content-listing .page-listing-item .page-item-detail")
            .map(function (f) {
            var name = f.find(".post-title a").hasValue ? f.find(".post-title a") : f.find("div > a");
            var title = name.text;
            return LightInfo.n()
                .Name(title)
                .Url(name.url("href"))
                .Type("Manga")
                .Image(f.find(".img-responsive").url("src", { Referer: _this.url + "/", webView: true }))
                .Info(f.first(".font-meta.chapter, .list-chapter .chapter-item:first-child a").text)
                .ParserName(_this.name);
        });
        // console.warn("items", items,  html.html)
        return items;
    };
    KunManga.prototype.search = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var gr, url, html;
            var _a, _b, _c;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        gr = ((_a = options.group) === null || _a === void 0 ? void 0 : _a.has()) ? (_b = options.group) === null || _b === void 0 ? void 0 : _b.lastOrDefault("value") : "";
                        url = this.url.join("https://kunmanga.com/page/", options.page.toString(), "?").query({
                            s: options.text.replace(/ /g, "+"),
                            post_type: "wp-manga",
                            author: "",
                            op: 1,
                            artist: "",
                            release: "",
                            m_orderby: gr,
                            adult: "",
                        });
                        (_c = options.genre) === null || _c === void 0 ? void 0 : _c.forEach(function (x) { return url = url.query({
                            "genre%5B%5D": x.value
                        }); });
                        if (gr == this.url) // latest
                            url = this.url.join("page", options.page.toString());
                        return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_d.sent()).html;
                        return [2 /*return*/, this.parse(html)];
                }
            });
        });
    };
    KunManga.prototype.group = function (value, page) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.search(SearchDetail.n().Group([value]).Page(page))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    KunManga.prototype.chapter = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, imgs;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        imgs = html.findAll(".reading-content img").map(function (x) { return "<img id=\"".concat(methods.newId(), "\" src='").concat(x.url("src", { Referer: _this.url + "/", webView: true }, function (x) { return x.trimStr(" ", "_").trim(); }), "'  />"); }).join("\n");
                        return [2 /*return*/, imgs];
                }
            });
        });
    };
    KunManga.prototype.detail = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, body, item;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        body = html.find("body");
                        item = DetailInfo.n();
                        item
                            .Name(body.find('.post-title').text)
                            .Url(url)
                            .Type("Manga")
                            .Image(body
                            .find('.summary_image img')
                            .url("src", { Referer: this.url + "/", webView: true }))
                            .Decription(body.find(".description-summary > .summary__content").text)
                            .Author("_")
                            .AuthorUrl(undefined)
                            .Genre(body
                            .find('.genres-content a')
                            .map(function (x) { return x.text; }))
                            .Status(body
                            .find('.post-status .post-content_item .summary__content').text)
                            .Rating(body
                            .find('.vote-details').text)
                            .LastUpdated(undefined)
                            .AlternativeNames(body.find('.post-content_item:contains("Alternative")').find(".summary-content").text)
                            .NovelUpdateRecommendations(body.findAll(".related-reading-wrap").map(function (x) { return (LightInfo.n()
                            .Name(x.find("a").text)
                            .Url(x.find("a").url("href"))
                            .Type("Manga")
                            .Image(x.find(".img-responsive").url("src", { Referer: _this.url + "/", webView: true }))
                            .ParserName(_this.name)); }))
                            .Tags(body.findAll(".wp-manga-tags-list a").map(function (x) { return x.text; }))
                            .ParserName(this.name);
                        item.Chapters(body.findAll(".page-content-listing .listing-chapters_wrap .wp-manga-chapter a")
                            .map(function (a) {
                            return ChapterInfo.n()
                                .Name(a.text)
                                .Url(a.url("href"))
                                .ParserName(_this.name);
                        }).reverse());
                        return [2 /*return*/, item];
                }
            });
        });
    };
    return KunManga;
}(Parser));
