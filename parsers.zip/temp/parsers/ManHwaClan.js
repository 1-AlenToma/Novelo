var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require("../native"), HttpHandler = _a.HttpHandler, Html = _a.Html, Value = _a.Value, ChapterInfo = _a.ChapterInfo, LightInfo = _a.LightInfo, DetailInfo = _a.DetailInfo, ParserDetail = _a.ParserDetail, SearchDetail = _a.SearchDetail, Parser = _a.Parser;
var ManHwaClan = /** @class */ (function (_super) {
    __extends(ManHwaClan, _super);
    function ManHwaClan() {
        var _this = _super.call(this, "https://manhwaclan.com", "ManHwaClan", "/favicon.ico", "Manga") || this;
        _this.infoGeneratorName = "AnimePlanet";
        _this.settings.searchEnabled = false;
        _this.settings.genreMultiSelection = false;
        _this.settings.searchCombination = [];
        _this.minVersion = 122;
        _this.protected = true;
        return _this;
    }
    ManHwaClan.prototype.load = function () {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(this.url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        this.settings.Genre(html.$(".sub-nav_list a").filter(function (x) { return x.attr("href").has("genre/"); }).map(function (x) {
                            return Value.n()
                                .Text(x.text)
                                .Value(x.attr("href").split("/").filter(function (x) { return x.has(); }).lastOrDefault());
                        }));
                        this.settings.Group([
                            Value.n()
                                .Text("Latest Manga")
                                .Value("trending"),
                            Value.n()
                                .Text("Most View")
                                .Value("views"),
                            Value.n()
                                .Text("New Manga")
                                .Value("new-manga")
                        ]);
                        return [2 /*return*/, this.settings];
                }
            });
        });
    };
    ManHwaClan.prototype.parse = function (html) {
        var _this = this;
        var items = html.$(".page-item-detail, .search-wrap .tab-content-wrap .row")
            .map(function (f) {
            // console.log(f.html)
            var name = f.find(".img-responsive").parent;
            var title = f.find(".post-title").text;
            return LightInfo.n()
                .Name(title)
                .Url(name.url("href"))
                .Type("Manga")
                .Image(name.find("img").url("src|srcset", { Referer: _this.url + "/", webView: true }))
                .Info(f.first(".list-chapter span:first-child, .latest-chap .chapter a").text)
                .ParserName(_this.name);
        });
        return items;
    };
    ManHwaClan.prototype.search = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var url, html;
            var _a, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        url = this.url.join("page", "#page").query({
                            s: options.text.replace(/ /g, "+"),
                            post_type: "wp-manga",
                            op: "",
                            author: "",
                            artist: "",
                            release: "",
                            adult: "",
                        });
                        if ((_a = options.group) === null || _a === void 0 ? void 0 : _a.has()) {
                            url += "&m_orderby=" + options.group.lastOrDefault("value");
                        }
                        if ((_b = options.genre) === null || _b === void 0 ? void 0 : _b.has()) {
                            url += "&" + options.genre.map(function (x) { return "genre%5B%5D=".concat(x.value); }).join("&");
                        }
                        url = url.replace("#page", options.page.toString() + "/");
                        return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_c.sent()).html;
                        return [2 /*return*/, this.parse(html)];
                }
            });
        });
    };
    ManHwaClan.prototype.group = function (value, page) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.search(SearchDetail.n().Group([value]).Page(page))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    ManHwaClan.prototype.getByAuthor = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        return [2 /*return*/, this.parse(html)];
                }
            });
        });
    };
    ManHwaClan.prototype.chapter = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, imgs;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(url, this.url, {
                            props: {
                                imageSelector: {
                                    selector: ".reading-content img",
                                    attr: "src"
                                }
                            }
                        })];
                    case 1:
                        html = (_a.sent()).html;
                        imgs = html.findAll(".reading-content img")
                            .map(function (x) { return "<img id=\"".concat(methods.newId(), "\" src='").concat(x.attr("src"), "'  />"); })
                            .join("\n");
                        return [2 /*return*/, imgs];
                }
            });
        });
    };
    ManHwaClan.prototype.getChapters = function (uurl) {
        return __awaiter(this, void 0, void 0, function () {
            var url, data, json, e_1;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        url = "https://www.mangakakalot.gg/api/manga/".concat(uurl.safeSplit("/", -1), "/chapters?limit=90000&offset=0");
                        return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        data = _a.sent();
                        json = data.json;
                        if (json.data.chapters.length <= 0)
                            return [2 /*return*/, []];
                        return [2 /*return*/, json.data.chapters.map(function (a) { return ChapterInfo.n()
                                .Name(a.chapter_name)
                                .Url(uurl.join(a.chapter_slug))
                                .ParserName(_this.name); }).reverse()];
                    case 2:
                        e_1 = _a.sent();
                        console.error(e_1);
                        return [2 /*return*/, []];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ManHwaClan.prototype.detail = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, body, item;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        body = html.find("body");
                        item = DetailInfo.n();
                        item
                            .Name(body.find('.post-title').text)
                            .Url(url)
                            .Type("Manga")
                            .Image(body.find('.summary_image img').url("src", { Referer: this.url + "/", webView: true }))
                            .Decription(body.find(".description-summary").text)
                            .Author(body.first('.author-content a').text)
                            .AuthorUrl(body.first('.author-content a').url("href"))
                            .Genre(body.find('.genres-content a').map(function (x) { return x.text; }))
                            .Status(body.first('.post-status .post-content_item .summary-content').text.replace(/Status|[ ]/gi, ""))
                            .Rating(body.first('.total_votes').text)
                            .ParserName(this.name);
                        item.Chapters(body.findAll(".listing-chapters_wrap a").map(function (a) { return ChapterInfo.n()
                            .Name(a.text)
                            .Url(_this.url.join(a.url("href")))
                            .ParserName(_this.name); }).reverse());
                        // item.Chapters(await this.getChapters(url))
                        /*  item.Chapters(
                              body.findAll(".manga-info-chapter .chapter-list a")
                                  .map(a =>
                                      ChapterInfo.n()
                                          .Name(a.text)
                                          .Url(a.url("href"))
                                          .ParserName(this.name)
                                  ).reverse()
                          );*/
                        return [2 /*return*/, item];
                }
            });
        });
    };
    return ManHwaClan;
}(Parser));
