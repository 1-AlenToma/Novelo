var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require("../native"), HttpHandler = _a.HttpHandler, Html = _a.Html, Value = _a.Value, ChapterInfo = _a.ChapterInfo, LightInfo = _a.LightInfo, DetailInfo = _a.DetailInfo, ParserDetail = _a.ParserDetail, SearchDetail = _a.SearchDetail, Parser = _a.Parser;
var MangaFire = /** @class */ (function (_super) {
    __extends(MangaFire, _super);
    function MangaFire() {
        var _this = _super.call(this, "https://mangaberri.com", "MangaBerri", "/favicon.ico", "Manga") || this;
        _this.infoGeneratorName = "";
        _this.settings.searchEnabled = false;
        _this.settings.genreMultiSelection = false;
        _this.settings.searchCombination = [];
        return _this;
    }
    MangaFire.prototype.load = function () {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        this.settings.Genre(html
                            .$(".category-popover a").map(function (x) {
                            return Value.n()
                                .Text(x.text)
                                .Value(x.attr("href"));
                        }));
                        this.settings.Group([
                            Value.n()
                                .Text("Top Weekly Manga")
                                .Value("/weekly-manga.php"),
                            Value.n()
                                .Text("New Manga")
                                .Value("/new-manga.php")
                        ]);
                        //console.warn([this.settings].niceJson());
                        return [2 /*return*/, this.settings];
                }
            });
        });
    };
    MangaFire.prototype.search = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var url, html, data;
            var _this = this;
            var _a, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        url = this.url.join("search.php").query({ keyword: options.text.replace(/ /gmi, "+") });
                        if ((_a = options.group) === null || _a === void 0 ? void 0 : _a.has()) {
                            url = this.url.join(options.group.firstOrDefault("value"));
                        }
                        if ((_b = options.genre) === null || _b === void 0 ? void 0 : _b.has()) {
                            url = this.url.join(options.genre.firstOrDefault("value"));
                        }
                        return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_c.sent()).html;
                        data = html.$(".manga-item")
                            .map(function (f) {
                            var _a;
                            var name = f.findAll(".link").eq(1);
                            if ((_a = f.find("img").attr("src")) === null || _a === void 0 ? void 0 : _a.has())
                                return LightInfo.n()
                                    .Name(name.text)
                                    .Url(name.url("href"))
                                    .Type("Manga")
                                    .Image(f.find("img").url("src") || f.find("img").attr("src"))
                                    .Info(f.findAll(".link").eq(2).text)
                                    .ParserName(_this.name);
                        }).filter(function (x) { return x != undefined; });
                        // console.warn(JSON.stringify(data, undefined, 4))
                        return [2 /*return*/, data];
                }
            });
        });
    };
    MangaFire.prototype.group = function (value, page) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.search(SearchDetail.n().Group([value]).Page(page))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MangaFire.prototype.getByAuthor = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, []]; // no data at the moment
            });
        });
    };
    MangaFire.prototype.chapter = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, imgs;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        imgs = html.first(".reading-container").findAll("img").map(function (x) { return "<img src=\"".concat(x.url("src") || x.attr("src"), "\"  />"); }).join("\n");
                        return [2 /*return*/, imgs];
                }
            });
        });
    };
    MangaFire.prototype.detail = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, body, item, css;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        body = html.find(".content-container");
                        item = DetailInfo.n();
                        item
                            .Name(body.find('.story-name').text)
                            .Url(url)
                            .Type("Manga")
                            .Image(body
                            .find('.comic-img')
                            .url("src"))
                            .Decription(body.find(".story-desc").text)
                            .Author(body.find('.comic-info-link[href*="author"]')
                            .text)
                            .AuthorUrl(body.find('.comic-info-link[href*="author"]').url("href"))
                            .Genre(body
                            .find('.comic-info-link[href*="genre"]')
                            .map(function (x) { return x.text; }))
                            .Status(body
                            .find('.section-status span:contains("Status")')
                            .parent.find("span:last-child").text)
                            .Rating(body
                            .find('.section-status span:contains("rating")')
                            .parent.find("span:last-child").text.replace("rating", "").trim().onEmpty("0.00"))
                            .LastUpdated(body.first('.text:contains("Updated On")').parent.find("span:last-child").text)
                            .ParserName(this.name);
                        css = "\n         body>*:not(#tbl_comments_wrapper){\n          display:none !important;\n          visibility: hidden;\n          opacity:0;\n          }\n\n          #tbl_comments_wrapper {\n            overflow:none;\n            height:100vh !important;\n            overflow-y:auto !important;\n            -webkit-overflow-scrolling: touch !important;\n            display:block !important;\n          }\n        ".replace(/(\r\n|\n|\r)/gm, "");
                        item.commentScript.Url(url).Script("\n        let scLoad = async function () {\n          let st =document.createElement(\"style\")\n           st.appendChild(document.createTextNode(\"".concat(css, "\"))\n          document.head.appendChild(st);\n          while(!document.getElementById(\"tbl_comments_wrapper\"))\n           await window.sleep(100);\n           let panel = document.getElementById(\"tbl_comments_wrapper\");\n           document.body.appendChild(panel);\n        }\n        scLoad();\n        "));
                        item.Chapters(body.findAll(".chapters-container > a")
                            .map(function (a) {
                            return ChapterInfo.n()
                                .Name(a.text)
                                .Url(a.url("href"))
                                .ParserName(_this.name);
                        }).reverse());
                        return [2 /*return*/, item];
                }
            });
        });
    };
    return MangaFire;
}(Parser));
