var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require("../native"), HttpHandler = _a.HttpHandler, html = _a.html, Value = _a.Value, ChapterInfo = _a.ChapterInfo, LightInfo = _a.LightInfo, DetailInfo = _a.DetailInfo, ParserDetail = _a.ParserDetail, SearchDetail = _a.SearchDetail, Parser = _a.Parser;
var ReadNovelFull = /** @class */ (function (_super) {
    __extends(ReadNovelFull, _super);
    function ReadNovelFull() {
        var _this = _super.call(this, "https://readnovelfull.com", "ReadNovelFull", "/img/favicon.ico") || this;
        _this.settings.searchEnabled = true;
        _this.settings.genreMultiSelection = false;
        _this.settings.searchCombination = ["Genre", "Status"];
        return _this;
    }
    ReadNovelFull.prototype.load = function () {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        this.settings.Genre(html
                            .$(".dropdown-menu a")
                            .filter(function (x) {
                            return x.attr("href").has("genres/");
                        })
                            .map(function (x) {
                            return Value.n()
                                .Text(x.text)
                                .Value(x.attr("href"));
                        }));
                        this.settings.Status([
                            Value.n()
                                .Text("Complated")
                                .Value("completed")
                        ]);
                        this.settings.Group(html
                            .$(".dropdown-menu a")
                            .filter(function (x) {
                            return x.attr("href").has("novel-list/");
                        })
                            .map(function (x) {
                            return Value.n()
                                .Text(x.text)
                                .Value(x.attr("href"));
                        }));
                        return [2 /*return*/, this.settings];
                }
            });
        });
    };
    ReadNovelFull.prototype.search = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var url, html;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.url.join("novel-list/search?keyword=".concat(options.text));
                        if (options.genre.has())
                            url = this.url.join(options.genre.lastOrDefault("value"), options.status.lastOrDefault("value"));
                        else if (options.group.has())
                            url = this.url.join(options.group.lastOrDefault("value"), options.status.lastOrDefault("value"));
                        url = url.query({
                            page: (1).sureValue(options.page)
                        });
                        return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        return [2 /*return*/, html
                                .$(".list-novel > .row")
                                .map(function (x) {
                                return x.map(function (f) {
                                    if (f.find(".cover").attr("src").has())
                                        return LightInfo.n()
                                            .Name(f.find(".novel-title").text)
                                            .Url(f.find(".novel-title a").url("href"))
                                            .Image(f
                                            .find(".cover")
                                            .url("src")
                                            .imageUrlSize("200x250"))
                                            .Info(f.find(".chr-text").text)
                                            .Decription(f.find(".author").text)
                                            .IsNew(f.find(".label-new").hasValue)
                                            .ParserName(_this.name);
                                });
                            })
                                .flatMap(function (x) { return x; })];
                }
            });
        });
    };
    ReadNovelFull.prototype.group = function (value, page) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.search(SearchDetail.n().Group([value]).Page(page))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    ReadNovelFull.prototype.getByAuthor = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        return [2 /*return*/, html
                                .$(".list-novel > .row")
                                .map(function (x) {
                                return x.map(function (f) {
                                    if (f.find(".cover").attr("src").has())
                                        return LightInfo.n()
                                            .Name(f.find(".novel-title").text)
                                            .Url(f
                                            .find(".novel-title a")
                                            .url("href"))
                                            .Image(f
                                            .find(".cover")
                                            .url("src")
                                            .imageUrlSize("200x250"))
                                            .Info(f.find(".chr-text").text)
                                            .Decription(f.find(".author").text)
                                            .IsNew(f.find(".label-new").hasValue)
                                            .ParserName(_this.name);
                                });
                            })
                                .flatMap(function (x) { return x; })];
                }
            });
        });
    };
    ReadNovelFull.prototype.chapter = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url)];
                    case 1:
                        html = (_a.sent()).html;
                        return [2 /*return*/, html.$(".chr-c").html];
                }
            });
        });
    };
    ReadNovelFull.prototype.detail = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, body, item, cHhtml;
            var _this = this;
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_b.sent()).html;
                        body = html.$("body");
                        item = DetailInfo.n();
                        item
                            .Name(body.find(".books .title").text)
                            .Url(url)
                            .Image(body
                            .find(".books img")
                            .url("src")
                            .imageUrlSize("200x250"))
                            .Decription(body.find(".desc-text").text)
                            .AlternativeNames(body
                            .find('.info-meta li h3:contains("Alternative")')
                            .parent.remove("h3").text)
                            .Author(body.first('.info-meta a[href*="authors"]')
                            .text)
                            .AuthorUrl(body.first('.info-meta a[href*="authors"]').url("href"))
                            .Genre(body
                            .find('.info-meta a[href*="genres"]')
                            .map(function (x) { return x.text; }))
                            .Status(body
                            .find('.info-meta li h3:contains("Status")')
                            .parent.find("a").text)
                            .Rating(body.find('span[itemprop="ratingValue"]')
                            .text)
                            .LastUpdated((_a = body.find("div.item-time").text) === null || _a === void 0 ? void 0 : _a.trim())
                            .ParserName(this.name);
                        item.commentScript.Url(url + "#tab-comment-title").Script("\n      let scLoad = async function () {\n        let st =document.createElement(\"style\")\n         st.appendChild(document.createTextNode(\"body>*:not(#novel-comment), #disqus_recommendations{ display:none !important;visibility: hidden;opacity:0;}\"))\n        document.head.appendChild(st);\n        while(!document.getElementById(\"novel-comment\"))\n         await window.sleep(100);\n         let panel = document.getElementById(\"novel-comment\");\n         document.body.appendChild(panel);\n      }\n      scLoad();\n      ");
                        return [4 /*yield*/, this.http.get_html(this.url
                                .join("ajax/chapter-archive")
                                .query({
                                novelId: html.find("[data-novel-id!=''][data-novel-id]").attr("data-novel-id")
                            }), this.url)];
                    case 2:
                        cHhtml = (_b.sent()).html;
                        item.Chapters(cHhtml
                            .$("li a")
                            .map(function (a) {
                            return ChapterInfo.n()
                                .Name(a.text)
                                .Url(a.url("href"))
                                .ParserName(_this.name);
                        }));
                        return [2 /*return*/, item];
                }
            });
        });
    };
    return ReadNovelFull;
}(Parser));
