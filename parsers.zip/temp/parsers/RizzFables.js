var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require("../native"), HttpHandler = _a.HttpHandler, Html = _a.Html, Value = _a.Value, ChapterInfo = _a.ChapterInfo, LightInfo = _a.LightInfo, DetailInfo = _a.DetailInfo, ParserDetail = _a.ParserDetail, SearchDetail = _a.SearchDetail, Parser = _a.Parser;
var RizzFables = /** @class */ (function (_super) {
    __extends(RizzFables, _super);
    function RizzFables() {
        var _this = _super.call(this, "https://rizzfables.com", "RizzFables", "/favicon.ico", "Manga") || this;
        _this.infoGeneratorName = "AnimePlanet";
        _this.settings.searchEnabled = true;
        _this.settings.genreMultiSelection = true;
        _this.settings.searchCombination = ["Genre", "Group", "Status"];
        _this.minVersion = 139;
        _this.protected = false;
        return _this;
    }
    RizzFables.prototype.load = function () {
        return __awaiter(this, void 0, void 0, function () {
            var html;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(this.url.join("series"), this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        this.settings.Genre(html.$("input[name='genre[]']").map(function (x) {
                            return Value.n()
                                .Text(x.parent.find("label").text.displayName())
                                .Value(x.attr("value"));
                        }));
                        this.settings.Status([
                            Value.n()
                                .Text("Completed")
                                .Value("completed"),
                            Value.n()
                                .Text("OnGoing")
                                .Value("ongoing")
                        ]);
                        this.settings.Group([
                            Value.n()
                                .Text("Latest")
                                .Value("latest"),
                            Value.n()
                                .Text("Updated")
                                .Value("update"),
                            Value.n()
                                .Text("Popular")
                                .Value("popular")
                        ]);
                        // console.warn([this.settings].niceJson());
                        return [2 /*return*/, this.settings];
                }
            });
        });
    };
    RizzFables.prototype.parse = function (json) {
        var _this = this;
        var items = (json !== null && json !== void 0 ? json : []).map(function (f) {
            return LightInfo.n()
                .Name(f.title)
                .Url(_this.url.join("series", "r2311170-" + f.title.toLowerCase()
                .trim()
                .replace(/[^a-z0-9\s-]/g, "")
                .replace(/\s+/g, "-")
                .replace(/-+/g, "-")))
                .Type("Manga")
                .Image(_this.url.join("assets/images", f.image_url))
                .Info("Chapter " + (f.latest_chapter_title || f.chapters_count || f.chapter_title || ""))
                .ParserName(_this.name);
        });
        // console.warn("items", items,  html.html)
        return items;
    };
    RizzFables.prototype.search = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var url, form, html;
            var _a, _b, _c, _d;
            return __generator(this, function (_e) {
                switch (_e.label) {
                    case 0:
                        url = "/Index/filter_series";
                        form = new FormData();
                        if (((_a = options.text) === null || _a === void 0 ? void 0 : _a.has()) != true) {
                            form.append("StatusValue", ((_b = options.status) === null || _b === void 0 ? void 0 : _b.lastOrDefault("value")) || "all");
                            form.append("TypeValue", "all");
                            form.append("OrderValue", ((_c = options.group) === null || _c === void 0 ? void 0 : _c.lastOrDefault("value")) || "all");
                            (_d = options.genre) === null || _d === void 0 ? void 0 : _d.forEach(function (x) { return form.append("genres_checked[]", x.value); });
                        }
                        else {
                            url = "/Index/live_search";
                            form.append("search_value", options.text);
                        }
                        return [4 /*yield*/, this.http.encodedPostWeb_view(this.url, {
                                url: url,
                                query: form,
                                type: "post",
                                method: "formPost"
                            })];
                    case 1:
                        html = (_e.sent()).json;
                        return [2 /*return*/, this.parse(html)];
                }
            });
        });
    };
    RizzFables.prototype.group = function (value, page) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.search(SearchDetail.n().Group([value]).Page(page))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    RizzFables.prototype.chapter = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, imgs;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.get_html(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        imgs = html.findAll("#readerarea img").map(function (x) { return "<img id=\"".concat(methods.newId(), "\" src='").concat(x.url("src", { Referer: _this.url + "/" }, function (x) { return x.trimStr(" ", "_").trim(); }), "'  />"); }).join("\n");
                        return [2 /*return*/, imgs];
                }
            });
        });
    };
    RizzFables.prototype.detail = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            var html, body, item, imptd;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http.web_view(url, this.url)];
                    case 1:
                        html = (_a.sent()).html;
                        body = html.find("body");
                        item = DetailInfo.n();
                        imptd = body.findAll(".imptdt");
                        item
                            .Name(body.find('.entry-title').text)
                            .AlternativeNames(body.find(".alternative").text)
                            .Url(url)
                            .Type(imptd.find(function (x) { return x.text.has("type") && x.text.has("Novel"); }).hasValue ? "Novel" : "Manga")
                            .Image(body
                            .find('.thumb > img')
                            .url("src", { Referer: this.url + "/" }))
                            .Decription(body.find("#description-container").text)
                            .Author(imptd.find(function (x) { return x.text.has("Author"); }).find("i").text)
                            .AuthorUrl(undefined)
                            .Genre(body.findAll('.mgen a[href*="genre"]').map(function (x) { return x.text; }))
                            .Status(imptd.find(function (x) { return x.text.has("Status"); }).find("i").text)
                            .Rating("")
                            .LastUpdated(imptd.find(function (x) { return x.text.has("Updated On"); }).find("i").text).ParserName(this.name);
                        item.Chapters(body.findAll("#chapterlist li")
                            .map(function (a) {
                            var dNmum = a.attr("data-num");
                            return ChapterInfo.n()
                                .Name(dNmum.has() ? "Chapter ".concat(dNmum) : a.find("a span:first-child").remove("i").text.replace(/\r?\n|\r/g, ""))
                                .Url(a.find("a").url("href"))
                                .ParserName(_this.name);
                        }).reverse());
                        return [2 /*return*/, item];
                }
            });
        });
    };
    return RizzFables;
}(Parser));
