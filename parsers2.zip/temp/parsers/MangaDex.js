const native_1 = require("../native");
class MangaDex extends native_1.Parser {
    constructor() {
        super("https://api.mangadex.org", "MangaDex", "https://mangadex.org", "Manga");
        this.infoGeneratorName = "";
        this.settings.searchEnabled = true;
        this.settings.genreMultiSelection = true;
        this.settings.searchCombination = ["Genre", "Status", "Group"];
        this.minVersion = 156;
        this.http.baseHeader = {
            "User-Agent": "MangaReaderApp/1.0 (Android; https://github.com/1-AlenToma/Novelo)",
            "Accept": "application/json",
            "Cache-Control": "no-store",
        };
    }
    async fetchJson(url) {
        const text = await this.http.get_html(url, this.url);
        let data = text.json;
        return data;
    }
    getImage(img, cacheIt) {
        let header = { "User-Agent": null };
        if (cacheIt)
            header.cacheIt = cacheIt;
        img += ` header=${JSON.stringify(header)}`;
        return img;
    }
    getLocalizedText(obj) {
        if (!obj)
            return "";
        if (obj.en)
            return obj.en;
        const keys = Object.keys(obj);
        return keys.length > 0 ? obj[keys[0]] : "";
    }
    async load() {
        const tagRes = await this.fetchJson(`${this.url}/manga/tag`);
        const tags = (tagRes?.data || []).map((t) => native_1.Value.n()
            .set("text", this.getLocalizedText(t.attributes?.name))
            .set("value", t.id));
        this.settings.set("genre", tags);
        this.settings.set("group", [
            native_1.Value.n().set("text", "Latest Updates").set("value", "latest"),
            native_1.Value.n().set("text", "Most Followed").set("value", "popular")
        ]);
        this.settings.set("status", [
            native_1.Value.n().set("text", "All").set("value", ""),
            native_1.Value.n().set("text", "Ongoing").set("value", "ongoing"),
            native_1.Value.n().set("text", "Completed").set("value", "completed"),
            native_1.Value.n().set("text", "Hiatus").set("value", "hiatus"),
            native_1.Value.n().set("text", "Cancelled").set("value", "cancelled")
        ]);
        return this.settings;
    }
    async search(options) {
        const limit = 24;
        const page = options.page || 1;
        const offset = (page - 1) * limit;
        const params = [
            `limit=${limit}`,
            `offset=${offset}`,
            `includes[]=cover_art`,
            `contentRating[]=safe`,
            `contentRating[]=suggestive`
        ];
        if (options.text && options.text.trim() !== "") {
            params.push(`title=${encodeURIComponent(options.text.trim())}`);
        }
        const sortVal = options.status?.firstOrDefault("value") || "";
        if (sortVal === "popular") {
            params.push(`order[followedCount]=desc`);
        }
        else if (sortVal === "latest") {
            params.push(`order[latestUploadedChapter]=desc`);
        }
        else if (sortVal !== "") {
            params.push(`status[]=${encodeURIComponent(sortVal)}`);
            params.push(`order[latestUploadedChapter]=desc`);
        }
        else {
            params.push(`order[relevance]=desc`);
        }
        if (options.genre && options.genre.length > 0) {
            options.genre.forEach((g) => {
                const tagId = typeof g === "string" ? g : g.value;
                if (tagId)
                    params.push(`includedTags[]=${encodeURIComponent(tagId)}`);
            });
        }
        const searchUrl = `${this.url}/manga?${params.join("&")}`;
        const res = await this.fetchJson(searchUrl);
        return (res?.data || []).map((manga) => {
            const id = manga.id;
            const attr = manga.attributes || {};
            const title = this.getLocalizedText(attr.title);
            const coverRel = (manga.relationships || []).find((r) => r.type === "cover_art");
            const fileName = coverRel?.attributes?.fileName;
            const coverUrl = fileName ? this.getImage(`https://uploads.mangadex.org/covers/${id}/${fileName}.256.jpg`) : "";
            return native_1.LightInfo.n()
                .set("name", title)
                .set("url", `${this.url}/manga/${id}`)
                .set("type", "Manga")
                .set("image", coverUrl)
                .set("info", (attr.status || "").toUpperCase())
                .set("parserName", this.name);
        });
    }
    async group(value, page) {
        return await this.search(native_1.SearchDetail.n().set("status", [value], "page", page));
    }
    async getByAuthor(url) {
        const authorId = url.split("/").pop();
        if (!authorId)
            return [];
        const res = await this.fetchJson(`${this.url}/manga?authors[]=${authorId}&limit=50&includes[]=cover_art`);
        return (res?.data || []).map((manga) => {
            const id = manga.id;
            const coverRel = (manga.relationships || []).find((r) => r.type === "cover_art");
            const fileName = coverRel?.attributes?.fileName;
            const coverUrl = fileName
                ? this.getImage(`https://uploads.mangadex.org/covers/${id}/${fileName}.256.jpg`)
                : "";
            return native_1.LightInfo.n()
                .set("name", this.getLocalizedText(manga.attributes?.title))
                .set("url", `${this.url}/manga/${id}`)
                .set("type", "Manga")
                .set("image", coverUrl)
                .set("info", (manga.attributes?.status || "").toUpperCase())
                .set("parserName", this.name);
        });
    }
    async chapter(url) {
        const chapterId = url.split("/").pop();
        const atHomeRes = await this.fetchJson(`${this.url}/at-home/server/${chapterId}`);
        const baseUrl = atHomeRes?.baseUrl;
        const hash = atHomeRes?.chapter?.hash;
        const pages = atHomeRes?.chapter?.data || [];
        return pages
            .map((filename) => {
            const src = this.getImage(`${baseUrl}/data/${hash}/${filename}`, true);
            return `<img src="${src}" />`;
        })
            .join("\n");
    }
    async detail(url) {
        const mangaId = url.split("/").pop();
        const mangaRes = await this.fetchJson(`${this.url}/manga/${mangaId}?includes[]=cover_art&includes[]=author`);
        const data = mangaRes?.data || {};
        const attr = data.attributes || {};
        const rels = data.relationships || [];
        const coverRel = rels.find((r) => r.type === "cover_art");
        const coverFile = coverRel?.attributes?.fileName;
        const coverUrl = coverFile ? this.getImage(`https://uploads.mangadex.org/covers/${mangaId}/${coverFile}`) : "";
        const authorRel = rels.find((r) => r.type === "author");
        const authorName = authorRel?.attributes?.name || "";
        const authorUrl = authorRel?.id ? `${this.url}/author/${authorRel.id}` : "";
        const genres = (attr.tags || []).map((t) => this.getLocalizedText(t.attributes?.name));
        const statusRaw = attr.status || "ongoing";
        const statusFormatted = statusRaw.charAt(0).toUpperCase() + statusRaw.slice(1);
        const feedRes = await this.fetchJson(`${this.url}/manga/${mangaId}/feed?translatedLanguage[]=en&limit=500&order[chapter]=asc&includeExternalUrl=0`);
        const chapters = (feedRes?.data || []).map((ch) => {
            const cAttr = ch.attributes || {};
            const chNum = cAttr.chapter ? `Ch. ${cAttr.chapter}` : "Oneshot";
            const chTitle = cAttr.title ? ` - ${cAttr.title}` : "";
            return native_1.ChapterInfo.n()
                .set("name", `${chNum}${chTitle}`)
                .set("url", `${this.url}/chapter/${ch.id}`)
                .set("parserName", this.name);
        });
        const item = native_1.DetailInfo.n();
        item
            .set("name", this.getLocalizedText(attr.title))
            .set("url", url)
            .set("type", "Manga")
            .set("image", coverUrl)
            .set("decription", this.getLocalizedText(attr.description))
            .set("author", authorName)
            .set("authorUrl", authorUrl)
            .set("genre", genres)
            .set("status", statusFormatted)
            .set("rating", "0.00")
            .set("lastUpdated", attr.updatedAt || "")
            .set("parserName", this.name)
            .set("chapters", chapters);
        return item;
    }
}
