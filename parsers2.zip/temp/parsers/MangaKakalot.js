const native_1 = require("../native");
class MangaKakalot extends native_1.Parser {
    constructor() {
        super("https://www.mangakakalot.gg", "MangaKakalot", "/favicon.ico", "Manga");
        this.infoGeneratorName = "AnimePlanet";
        this.settings.searchEnabled = false;
        this.settings.genreMultiSelection = false;
        this.settings.searchCombination = [];
        this.minVersion = 156;
        this.protected = true;
    }
    async load() {
        let html = (await this.http.web_view(this.url.join("genre/all"), this.url)).html;
        this.settings.set("genre", html.$("div a").filter(x => x.attr("href").has("genre/"))
            .map(x => native_1.Value.n()
            .set("text", x.text.replace(/\n\s+/g, " "))
            .set("value", x.attr("href"))));
        this.settings.set("group", [
            native_1.Value.n()
                .set("text", "Latest Manga")
                .set("value", "/manga-list/latest-manga"),
            native_1.Value.n()
                .set("text", "Hot Manga")
                .set("value", "/manga-list/hot-manga"),
            native_1.Value.n()
                .set("text", "New Manga")
                .set("value", "/manga-list/new-manga")
        ]);
        return this.settings;
    }
    parse(html) {
        let items = html.$(".grid .group, .list-comic-item-wrap, .story_item")
            .map(f => {
            let name = f.find("h3 a").hasValue ? f.find("h3 a") : f.first("a").parent;
            let title = name.attr("title").has() ? name.attr("title") : name.text;
            return native_1.LightInfo.n()
                .set("name", title)
                .set("url", name.url("href"))
                .set("type", "Manga")
                .set("image", f.find("img").url("src", { Referer: this.url + "/" }))
                .set("info", f.run(".absolute.bottom-1.5,.list-story-item-wrap-chapter, .story_item_right > .story_chapter:first-child -> text"))
                .set("parserName", this.name);
        });
        return items;
    }
    async search(options) {
        let url = this.url.join("search/story/", options.text.replace(/ /g, "_"));
        if (options.group?.has()) {
            url = this.url.join(options.group.lastOrDefault("value"));
        }
        if (options.genre?.has()) {
            url = this.url.join(options.genre.lastOrDefault("value"));
        }
        url = url.query({
            page: options.page,
            q: options.text.replace(/ /g, "_")
        });
        let html = (await this.http.web_view(url, this.url)).html;
        return this.parse(html);
    }
    async group(value, page) {
        return await this.search(native_1.SearchDetail.n().set("group", [value], "page", page));
    }
    async getByAuthor(url) {
        let html = (await this.http.web_view(url, this.url)).html;
        return this.parse(html);
    }
    async chapter(url) {
        let html = (await this.http.web_view(url, this.url)).removeScripts().html;
        let imgs = html.findAll("div[data-reader-column='true'] img, .container-chapter-reader img")
            .map(x => `<img id="$id" loading="lazy" src='$src' />`.formatString(methods.newId(), x.attr("src").has("Cached_") ? x.attr("src") : x.url("src", { Referer: this.url + "/", cacheIt: true, parserName: this.name })));
        return imgs.join("\n");
    }
    async getChapters(uurl) {
        try {
            const url = `https://www.mangakakalot.gg/api/manga/$url/chapters?limit=90000&offset=0`.formatString(uurl.safeSplit("/", -1));
            const data = await this.http.get_html(url, this.url);
            const json = data.json;
            if (json.data.chapters.length <= 0)
                return [];
            return json.data.chapters.map(a => native_1.ChapterInfo.n()
                .set("name", a.chapter_name)
                .set("url", uurl.join(a.chapter_slug))
                .set("parserName", this.name)).reverse();
        }
        catch (e) {
            console.error("getChapters", e);
            return [];
        }
    }
    async detail(url) {
        let html = (await this.http.web_view(url, this.url)).removeScripts().html;
        let body = html.find("body");
        let item = native_1.DetailInfo.n()
            .set("name", body.run('.container h1, .manga-info-text h1 -> text'))
            .set("url", url)
            .set("type", "Manga")
            .set("image", body.find('img.object-cover,.manga-info-pic img').url("src", { Referer: this.url + "/" }))
            .set("decription", body.run(".prose-summary, #contentBox -> remove::h2 -> text"))
            .set("genre", body.run('.container a[href*="genre"], .genres a -> map::text'))
            .set("status", body.find('span:contains("Ongoing"), .manga-info-text li:contains("Ongoing")').hasValue ? "Ongoing" : "Completed")
            .set("parserName", this.name);
        item.set("chapters", await this.getChapters(url));
        return item;
    }
}
