"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ParserItems_1 = require("../native/ParserItems");
const ReadNovelFull_1 = __importDefault(require("./ReadNovelFull"));
const NovelFull_1 = __importDefault(require("./NovelFull"));
const NovelFullCom_1 = __importDefault(require("./NovelFullCom"));
const MangaBerri_1 = __importDefault(require("./MangaBerri"));
const Novelbin_1 = __importDefault(require("./Novelbin"));
const NovelBinCom_1 = __importDefault(require("./NovelBinCom"));
const GogoAnime_1 = __importDefault(require("./GogoAnime"));
const MangaKakalot_1 = __importDefault(require("./MangaKakalot"));
const KunManga_1 = __importDefault(require("./KunManga"));
const RizzFables_1 = __importDefault(require("./RizzFables"));
const ManHwaClan_1 = __importDefault(require("./ManHwaClan"));
const WtrLabCom_1 = __importDefault(require("./WtrLabCom"));
const NovelUpdates_1 = __importDefault(require("./infos/NovelUpdates"));
const MyAnimeList_1 = __importDefault(require("./infos/MyAnimeList"));
const WebNovel_1 = __importDefault(require("./infos/WebNovel"));
const AnimePlanet_1 = __importDefault(require("./infos/AnimePlanet"));
const Memo_1 = __importDefault(require("../attr/Memo"));
const react_native_short_style_1 = require("react-native-short-style");
const daysToSave = (nr = 5) => {
    if (!context.appSettings.autoUpdateFavoritNovels)
        return undefined;
    return nr;
};
const debugg = false;
let ParserWrapper = (() => {
    var _a;
    let _classSuper = ParserItems_1.Parser;
    let _instanceExtraInitializers = [];
    let _detail_decorators;
    let _novelInfo_decorators;
    let _getByAuthor_decorators;
    let _load_decorators;
    let _group_decorators;
    return _a = class ParserWrapper extends _classSuper {
            constructor(parser) {
                super(parser.url, parser.name, parser.icon, parser.type);
                this.parser = __runInitializers(this, _instanceExtraInitializers);
                this.infoGeneratorName = "NovelUpdate";
                this.infoEnabled = true;
                this.parser = parser;
                this.settings = parser.settings;
                this.novelUpdate = new NovelUpdates_1.default();
                this.animeInfo = new MyAnimeList_1.default();
                this.webNovel = new WebNovel_1.default();
                this.animePlanetInfo = new AnimePlanet_1.default();
                this.infoGeneratorName = parser.infoGeneratorName;
                this.minVersion = parser.minVersion;
                this.protected = parser.protected ?? false;
                this.enabled = parser.enabled;
            }
            dispose() {
                this.http.subressErrors = this.parser.http.subressErrors = true;
                this.http.clearOperations(undefined, true);
                this.parser.http.clearOperations(undefined, true);
            }
            getContext() {
                return context;
            }
            getError() {
                return this.parser.http.httpError;
            }
            clearError() {
                this.parser.http.httpError = undefined;
                return this;
            }
            showError() {
                if (this.getError())
                    react_native_short_style_1.AlertDialog.toast({ title: "OFFLINE", message: this.getError()?.toString(), type: "Error" });
            }
            static getAllParsers(parserName) {
                let prs = [ReadNovelFull_1.default,
                    NovelFullCom_1.default,
                    NovelFull_1.default,
                    NovelBinCom_1.default,
                    Novelbin_1.default,
                    RizzFables_1.default,
                    KunManga_1.default,
                    MangaKakalot_1.default,
                    MangaBerri_1.default,
                    GogoAnime_1.default,
                    ManHwaClan_1.default,
                    WtrLabCom_1.default
                ].map(x => new _a(new x()));
                if (parserName)
                    return prs.find(x => x.name === parserName);
                return prs;
            }
            async detail(url, alertOnError, renewMemo) {
                let item = await this.parser.detail(url);
                if (alertOnError)
                    this.showError();
                return item;
            }
            async search(options, alertOnError) {
                let item = await this.parser.search(options);
                if (alertOnError)
                    this.showError();
                return item;
            }
            async novelInfo(item, alertOnError) {
                let novel = item;
                switch (this.infoGeneratorName) {
                    case "NovelUpdate":
                        novel = await this.novelUpdate.search(item);
                        if (!novel.novelUpdateUrl || novel.novelUpdateRating.empty())
                            novel = await this.webNovel.search(item);
                        break;
                    case "MyAnimeList":
                        novel = await this.animeInfo.search(item);
                        break;
                    case "AnimePlanet":
                        novel = await this.animePlanetInfo.search(item, (item.type ?? "manga").toLowerCase());
                        break;
                    default:
                        novel = null;
                        break;
                }
                if (alertOnError)
                    this.showError();
                return novel;
            }
            async getByAuthor(url) {
                return await this.parser.getByAuthor(url);
            }
            async fetchSelectorImage(selector) {
                try {
                    let baseUrl = selector
                        .safeSplit("]", 0)
                        .replace(/\[|\]/g, "");
                    let url = selector
                        .safeSplit("]", 1)
                        .replace(/\[|\]/g, "");
                    let path = selector
                        .safeSplit("]", 2)
                        .replace(/\[|\]/g, "");
                    let attr = selector
                        .safeSplit("]", 3)
                        .replace(/\[|\]/g, "");
                    let html = (await this.http.get_html(url, baseUrl)).html;
                    return html.$(path).url(attr);
                }
                catch (e) { }
                return "";
            }
            async load(renewMemo) {
                try {
                    console.info("loading parser settings");
                    return await this.parser.load();
                }
                catch (e) {
                    console.error("error", e);
                }
            }
            async group(value, page, alertOnError, renewMemo) {
                try {
                    let item = await this.parser.group(value, page);
                    if (alertOnError)
                        this.showError();
                    return item;
                }
                catch (e) {
                    console.error("group", value, e);
                    if (alertOnError)
                        this.showError();
                    return [];
                }
            }
            async chapter(url, alertOnError) {
                let item = await this.parser.chapter(url);
                if (alertOnError)
                    this.showError();
                return item;
            }
        },
        (() => {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _detail_decorators = [(0, Memo_1.default)({
                    daysToSave: daysToSave,
                    folder: (target) => target.name,
                    isDebug: debugg,
                    argsOverride: (args) => {
                        return args[0];
                    },
                    keyModifier: (target, key) => `${key}${target.name}`,
                    validator: (data) => data &&
                        !data.name.empty() &&
                        !data.url.empty() &&
                        data.chapters &&
                        data.chapters.length > 0
                })];
            _novelInfo_decorators = [(0, Memo_1.default)({
                    daysToSave: daysToSave,
                    folder: (target) => target.name,
                    isDebug: debugg,
                    argsOverride: (args) => {
                        return [args.firstOrDefault("url")];
                    },
                    updateIfTrue: (args) => {
                        let url = args?.novelUpdateUrl;
                        return !url || (url || "").empty();
                    },
                    keyModifier: (target, key) => `${key}${target.name}`,
                    validator: (data) => data &&
                        !data.name.empty() &&
                        !data.url.empty() &&
                        data.chapters &&
                        data.chapters.length > 0
                        && data.novelUpdateUrl && data.novelUpdateUrl.length > 0
                })];
            _getByAuthor_decorators = [(0, Memo_1.default)({
                    daysToSave: () => daysToSave(20),
                    isDebug: debugg,
                    folder: (target) => target.name,
                    keyModifier: (target, key) => `${key}${target.name}`,
                    validator: (data) => data &&
                        data.has() &&
                        !data[0].name.empty() &&
                        !data[0].url.empty()
                })];
            _load_decorators = [(0, Memo_1.default)({
                    daysToSave: () => daysToSave(20),
                    isDebug: debugg,
                    folder: (target) => target.name,
                    keyModifier: (target, key) => `${key}${target.name}`,
                    validator: (data) => data &&
                        (data.status?.has() ||
                            data.genre?.has() ||
                            data.group?.has())
                })];
            _group_decorators = [(0, Memo_1.default)({
                    daysToSave: 2,
                    isDebug: debugg,
                    folder: (target) => target.name,
                    keyModifier: (target, key) => `group_${key}${target.name}`,
                    argsOverride: (args) => [args[0], args[1]],
                    validator: (data) => data && data.has() && !data[0].name.empty() && !data[0].url.empty()
                })];
            __esDecorate(_a, null, _detail_decorators, { kind: "method", name: "detail", static: false, private: false, access: { has: obj => "detail" in obj, get: obj => obj.detail }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(_a, null, _novelInfo_decorators, { kind: "method", name: "novelInfo", static: false, private: false, access: { has: obj => "novelInfo" in obj, get: obj => obj.novelInfo }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(_a, null, _getByAuthor_decorators, { kind: "method", name: "getByAuthor", static: false, private: false, access: { has: obj => "getByAuthor" in obj, get: obj => obj.getByAuthor }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(_a, null, _load_decorators, { kind: "method", name: "load", static: false, private: false, access: { has: obj => "load" in obj, get: obj => obj.load }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(_a, null, _group_decorators, { kind: "method", name: "group", static: false, private: false, access: { has: obj => "group" in obj, get: obj => obj.group }, metadata: _metadata }, null, _instanceExtraInitializers);
            if (_metadata) Object.defineProperty(_a, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        })(),
        _a;
})();
